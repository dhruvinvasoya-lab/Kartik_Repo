import io.testgrid.listeners.TestListener;
import io.testgrid.listeners.RetryFailedTestCases;
import io.testgrid.tg;
import org.testng.annotations.*;
import app.getxray.xray.testng.annotations.XrayTest;
import io.testgrid.enums.ComparisonType;
import org.json.JSONObject;
import io.testgrid.enums.Direction;
import io.testgrid.enums.Size;
import io.testgrid.enums.Buttons;
import static io.testgrid.baseClass.driver;
import org.openqa.selenium.*;
import io.testgrid.enums.Alert;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.testng.annotations.Test;

@Listeners(TestListener.class);
public class tc01 {

	@Test(retryAnalyzer = RetryFailedTestCases.class)
	public void tc01() {
		tg.openDevice();
				tg.wait(5);
				tg.click("ele_OKButton1783707870668", 1);
				tg.wait("ele_mainmenusearchcityTextView1783707181807", ComparisonType.IS_VISIBLE);
				tg.click("ele_mainmenusearchcityTextView1783707181807", 1);
				tg.wait("ele_LondonTextView1783707187483", ComparisonType.IS_VISIBLE);
				tg.click("ele_LondonTextView1783707187483", 1);
				tg.wait("ele_OpennavigationdrawerImageButton1783707195801", ComparisonType.IS_VISIBLE);
				tg.click("ele_OpennavigationdrawerImageButton1783707195801", 1);
				tg.wait(5);
		tg.activateApp("com.google.android.youtube");
				tg.wait(5);
		tg.activateApp("com.android.chrome");
				tg.wait(5);
		tg.close();
	}
}